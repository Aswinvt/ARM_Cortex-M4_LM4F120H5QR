__stackless __arm
void _undef(void)
{
/* USER CODE BEGIN (2) */
/* USER CODE END */
}

__stackless __arm
void _svc(void)
{
/* USER CODE BEGIN (2) */
/* USER CODE END */
}

__stackless __arm
void _prefetch(void)
{
/* USER CODE BEGIN (2) */
/* USER CODE END */
}
